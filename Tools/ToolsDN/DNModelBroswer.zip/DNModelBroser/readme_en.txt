DragonNest Model Browser v1.0

operation:

* mouse left button : rotate scene
* mouse right button : translate scene
* mouse middle wheel : adjust far and near distance of the scene

* mouse right click on the item of the treeview, you can
	* Extract File... (extract raw data file)
	* Render Skin (need a .skn file selected)
	* Apply Animate (need a .ani file selected)
	* Export Animate... (export animate frame as bmp picture sequences)


by liuliqiang
forcewall@gmail.com
2010-07-31